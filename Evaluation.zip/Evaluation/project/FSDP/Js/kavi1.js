function goto()
{
window.location="login.html";
}
function toupper()
{
var str=document.getElementById("inp").value;
var j=document.getElementById("out");
j.value=str.toUpperCase();
}
function tolower()
{
var str=document.getElementById("inp").value;
var j=document.getElementById("out");
j.value=str.toLowerCase();
}